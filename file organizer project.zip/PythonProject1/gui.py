import tkinter as tk
from tkinter import filedialog, messagebox
from organizer import FileSorter

def browse_folder():
    folder_path = filedialog.askdirectory()
    entry.delete(0, tk.END)
    entry.insert(0, folder_path)

def organize():
    folder_path = entry.get()
    if not folder_path:
        messagebox.showwarning("Warning", "Please select a folder.")
        return

    try:
        sorter = FileSorter(folder_path)
        sorter.organize_files()
        messagebox.showinfo("Success", "Files organized successfully!")
    except Exception as e:
        messagebox.showerror("Error", f"Failed to organize files:\n{str(e)}")

# Tkinter GUI setup
root = tk.Tk()
root.title("File Organizer")
root.geometry("400x150")

label = tk.Label(root, text="Select Folder:")
label.pack(pady=5)

entry = tk.Entry(root, width=40)
entry.pack(pady=5)

browse_btn = tk.Button(root, text="Browse", command=browse_folder)
browse_btn.pack(pady=5)

organize_btn = tk.Button(root, text="Organize Files", command=organize)
organize_btn.pack(pady=10)

root.mainloop()
