import os
import shutil
import logging

class FileSorter:
    def __init__(self, folder_path):
        self.folder_path = folder_path
        self.extensions = {
            'Images': ['.jpg', '.jpeg', '.png', '.gif'],
            'Documents': ['.pdf', '.txt', '.docx'],
            'Videos': ['.mp4', '.mov'],
            'Others': []
        }

    def organize_files(self):
        if not os.path.exists(self.folder_path):
            raise FileNotFoundError(f"Folder not found: {self.folder_path}")

        for filename in os.listdir(self.folder_path):
            file_path = os.path.join(self.folder_path, filename)

            if os.path.isfile(file_path):
                ext = os.path.splitext(filename)[1].lower()
                moved = False

                for category, ext_list in self.extensions.items():
                    if ext in ext_list:
                        dest_folder = os.path.join(self.folder_path, category)
                        os.makedirs(dest_folder, exist_ok=True)
                        shutil.move(file_path, os.path.join(dest_folder, filename))
                        moved = True
                        break

                if not moved:
                    dest_folder = os.path.join(self.folder_path, 'Others')
                    os.makedirs(dest_folder, exist_ok=True)
                    shutil.move(file_path, os.path.join(dest_folder, filename))
